$(function() {

	$('.container,.footer').animate({
		top: '60px'
	}, 'slow');
	$('.container .message a').bind('click', function() {
		$('#register-module,#login-module').animate({
			height: 'toggle',
			opacity: 'toggle'
		}, 'slow');
	});
	$('#login-module .message a').bind('click', function() {
		$('.container,.footer').animate({
			top: '20px'
		}, 'slow');
	});
	$('#register-module .message a').bind('click', function() {
		$('.container,.footer').animate({
			top: '60px'
		}, 'slow');
	});

	/* 账号限制只能输入数字 */
	$('#login_phone,#register_phone').bind('input propertychange', function() {
		$(this).val($(this).val().replace(/[^\d]/g, ''));
	});

	/* 密码限制只能输入数字、字母、下划线) */
	$('#login_password,#register_password,#register_password2').bind('input propertychange', function() {
		$(this).val($(this).val().replace(/[^\w_]/g, ''));
	});

	/* 禁用密码输入框的copy paste cut操作 */
	$('#login_password,#register_password,#register_password2').bind('copy paste cut', function(event) {
		event.preventDefault();
	});

	/* 初始化验证码 */
	$('.verify-code').attr('src', tooltip.urlPrefix('/verification/code'));

	/* 错误时提示并抖动窗口 */
	const danger_prompt_shake = function(message) {
		tooltip.danger_prompt(message);
		$('.container').removeClass('shake_effect');
		setTimeout(function() {
			$('.container').addClass('shake_effect');
		}, 1);
	}

	/* 账号密码数据规范验证 */
	const phone_password_check = function(phone, password) {
		if (!phone) {
			danger_prompt_shake("账号不能为空！");
			return false;
		} else if (!password) {
			danger_prompt_shake("密码不能为空！");
			return false;
		} else if (!(/^(((13[0-9]{1})|(15[0-9]{1})|(18[0-9]{1}))+\d{8})$/.test(phone))) {
			danger_prompt_shake("账号格式不正确！");
			return false;
		} else if (password.length < 8) {
			danger_prompt_shake("密码由8-16位数字或字母组成！");
			return false;
		} else {
			return true;
		}
	}

	/* 登录数据规范验证 */
	const login_data_check = function() {
		const userId = $('#login-module input[name=userId]').val();
		const password = $('#login-module input[name=password]').val();
		const verifyCode = $('#login-module input[name=verify-code]').val();
		if (phone_password_check(userId, password)) {
			if (!verifyCode) {
				danger_prompt_shake("请输入验证码！");
			} else {
				user_login(userId, password, verifyCode);
			}
		}
	}

	/* 点击登录 */
	$('#login').bind('click', login_data_check);

	/* 提交数据开始登录 */
	const user_login = function(userId, password, verifyCode) {
		tooltip.mask_layer_layer();
		tooltip.request('/user/login', 'POST', function(response) {
			if (response['state']) {
				localStorage.setItem("key_token", response['data']);
				tooltip.success_prompt("登录成功!", 1500);
				window.location = 'chatroom.html';
			} else {
				danger_prompt_shake(response['message'], 1500);
			}
			setTimeout(function() {
				tooltip.mask_layer_remove();
			}, 1500);
		}, {
			'userId': userId,
			'password': password,
			'verifyCode': verifyCode
		});
	}

	/* 注册数据规范验证 */
	const register_data_check = function() {
		const userId = $('#register-module input[name=userId]').val();
		const password = $('#register-module input[name=password]').val();
		const reconfirm = $('#register-module input[name=reconfirm]').val();
		const verifyCode = $('#register-module input[name=verify-code]').val();
		if (phone_password_check(userId, password)) {
			if (!reconfirm) {
				danger_prompt_shake("二次密码不能为空！");
			} else if (password != reconfirm) {
				danger_prompt_shake("两次密码不一样！");
			} else if (!verifyCode) {
				danger_prompt_shake("请输入验证码！");
			} else {
				user_register(userId, password, verifyCode);
			}
		}
	}

	/* 点击开始注册 */
	$('#register').bind('click', register_data_check);

	/* 回到登录界面并自动填入登录数据 */
	const return_login = function(userId, password) {
		$('#register-module,#login-module')
			.animate({
				height: 'toggle',
				opacity: 'toggle'
			}, 'slow');
		$('.container,.footer').animate({
			top: '80px'
		}, 'slow');
		$('#login-module input[name=userId]').val(userId);
		$('#login-module input[name=password]').val(password);
	}

	/* 提交数据开始注册 */
	const user_register = function(userId, password, verifyCode) {
		tooltip.mask_layer_layer();
		tooltip.request('/user/register', 'POST', function(response) {
			if (response['state']) {
				tooltip.success_prompt(response['data'], 1500);
				return_login(userId, password);
			} else {
				danger_prompt_shake(response['message'], 1500);
			}
			setTimeout(function() {
				$('.verify-code').attr('src', tooltip.urlPrefix('/verification/code'));
				tooltip.mask_layer_remove();
			}, 1500);
		}, {
			'userId': userId,
			'password': password,
			'verifyCode': verifyCode
		});
	}

	/* 点刷新验证码 */
	$(".verify-code").bind('click', function() {
		$(this).attr('src', tooltip.urlPrefix('/verification/code'));
	});

	/* 定义按键事件(enter)，判断当前所属模块，分别提交 */
	$(document).bind('keydown', function(event) {
		if (event.which == 13) {
			preventDefault(event);
			if ($("#login-module").is(':hidden')) {
				register_data_check();
			} else {
				login_data_check();
			}
		}
	});

	/* 阻止事件冒泡 */
	function preventDefault(event) {
		if (event && event.preventDefault) {
			event.preventDefault();
		} else {
			window.event.returnValue = false;
		}
	}

})
