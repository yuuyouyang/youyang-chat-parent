/* 右键菜单 */
"use strict";
! function(n, t) {
	"undefined" != typeof module && module.exports ? module.exports = t() : "function" == typeof define && define.amd ?
		define(t) : window[n] = t()
}("basicContext", function() {
	let f = function() {
		if (d() === !1) return !1;
		const t = document.querySelector(".basicContextContainer");
		return t.parentElement.removeChild(t), null != n && (document.body.style.overflow = n, n = null), !0
	};
	let n = null,
		t = "item",
		e = "separator",
		i = function() {
			const n = arguments.length <= 0 || void 0 === arguments[0] ? "" : arguments[0];
			return document.querySelector(".basicContext " + n)
		},
		l = function() {
			const n = arguments.length <= 0 || void 0 === arguments[0] ? {} : arguments[0],
				i = 0 === Object.keys(n).length ? !0 : !1;
			return i === !0 && (n.type = e), null == n.type && (n.type = t), null == n["class"] && (n["class"] = ""), n.visible !==
				!1 && (n.visible = !0), null == n.icon && (n.icon = null), null == n.title && (n.title = "Undefined"), n.disabled !==
				!0 && (n.disabled = !1), n.disabled === !0 && (n["class"] += " basicContext__item--disabled"), null == n.fn && n.type !==
				e && n.disabled === !1 ? (console.warn("Missing fn for item '" + n.title + "'"), !1) : !0
		},
		o = function(n, i) {
			let o = "",
				r = "";
			return l(n) === !1 ? "" : n.visible === !1 ? "" : (n.num = i, null !== n.icon && (r =
					"<span class='basicContext__icon " + n.icon + "'></span>"), n.type === t ? o =
				"\n<tr class='basicContext__item " + n["class"] + "'>\n<td class='basicContext__data' data-num='" + n.num + "'>" +
				r + n.title + "</td>\n</tr>\n" : n.type === e && (o =
					"\n<tr class='basicContext__item basicContext__item--separator'></tr>\n"), o)
		},
		r = function(n) {
			let t = "";
			return t += "\n<div class='basicContextContainer'>\n<div class='basicContext'>\n<table>\n<tbody>\n", n.forEach(
				function(n, e) {
					return t += o(n, e)
				}), t += "\n</tbody>\n</table>\n</div>\n</div>\n"
		},
		a = function() {
			const n = arguments.length <= 0 || void 0 === arguments[0] ? {} : arguments[0],
				t = {
					x: n.clientX,
					y: n.clientY
				};
			if ("touchend" === n.type && (null == t.x || null == t.y)) {
				const e = n.changedTouches;
				null != e && e.length > 0 && (t.x = e[0].clientX, t.y = e[0].clientY)
			}
			return (null == t.x || t.x < 0) && (t.x = 0), (null == t.y || t.y < 0) && (t.y = 0), t
		},
		s = function(n, t) {
			let e = a(n),
				i = e.x,
				l = e.y,
				o = {
					width: window.innerWidth,
					height: window.innerHeight
				},
				r = {
					width: t.offsetWidth,
					height: t.offsetHeight
				};
			i + r.width > o.width && (i -= i + r.width - o.width), l + r.height > o.height && (l -= l + r.height - o.height), r
				.height > o.height && (l = 0, t.classList.add("basicContext--scrollable"));
			const s = e.x - i,
				u = e.y - l;
			return {
				x: i,
				y: l,
				rx: s,
				ry: u
			}
		},
		u = function() {
			const n = arguments.length <= 0 || void 0 === arguments[0] ? {} : arguments[0];
			return null == n.fn ? !1 : n.visible === !1 ? !1 : n.disabled === !0 ? !1 : (i("td[data-num='" + n.num + "']").onclick =
				n.fn, i("td[data-num='" + n.num + "']").oncontextmenu = n.fn, !0)
		},
		c = function(t, e, l, o) {
			const a = r(t);
			document.body.insertAdjacentHTML("beforeend", a), null == n && (n = document.body.style.overflow, document.body.style
				.overflow = "hidden");
			const c = i(),
				d = s(e, c);
			return c.style.left = d.x + "px", c.style.top = d.y + "px", c.style.transformOrigin = d.rx + "px " + d.ry + "px", c
				.style.opacity = 1, null == l && (l = f), c.parentElement.onclick = l, c.parentElement.oncontextmenu = l, t.forEach(
					u), "function" == typeof e.preventDefault && e.preventDefault(), "function" == typeof e.stopPropagation && e.stopPropagation(),
				"function" == typeof o && o(), !0
		},
		d = function() {
			const n = i();
			return null == n || 0 === n.length ? !1 : !0
		};
	return {
		ITEM: t,
		SEPARATOR: e,
		show: c,
		visible: d,
		close: f
	}
});

/* 定义一个工具类简化操作 */
const tooltip = new function Tooltip() {

	this.location_host = 'localhost:8080';

	this.urlPrefix = function(_url) {
		return 'http://' + this.location_host + _url;
	}

	this.thumbnailUrl = function(filename) {
		return 'http://' + this.location_host + '/thumbnail?filename=' + filename;
	}
	
	this.downloadUrl = function(filename) {
		return 'http://' + this.location_host + '/download?filename=' + filename;
	}

	/* 使用ajax发起一个请求 */
	this.request = function(_url, _type, callback, _data) {
		const token = localStorage.getItem("key_token");
		if (_type == 'GET' || _type == 'POST') {
			$.ajax({
				url: this.urlPrefix(_url),
				type: _type,
				data: _data,
				dataType: 'json',
				cache: true,
				headers: {
					Authorization: token
				},
				success: function(response) {
					callback(response);
				}
			});
		} else {
			$.ajax({
				url: this.urlPrefix(_url),
				type: _type,
				data: JSON.stringify(_data),
				contentType: 'application/json',
				dataType: 'json',
				cache: true,
				headers: {
					Authorization: token
				},
				success: function(response) {
					callback(response);
				}
			});
		}
	}

	this.requestLog = function(_url, _type, callback, _data) {
		tooltip.request(_url, _type, function(response) {
			if (response['state']) {
				callback(response['data']);
			} else {
				console.log(response);
			}
		}, _data);
	}

	/* 使用ajax进行文件上传操作 */
	this.uploadFile = function(_url, callback, _data) {
		const token = localStorage.getItem("key_token");
		$.ajax({
			url: this.urlPrefix(_url),
			type: 'POST',
			data: _data,
			headers: {
				Authorization: token
			},
			dataType: 'json',
			cache: true,
			processData: false,
			contentType: false,
			success: function(response) {
				callback(response);
			}
		});
	}

	/* 遮罩层 */
	this.mask_layer_layer = function() {
		$('body').append('<div id="popWindow" class="popWindow"></div>');
	}
	this.mask_layer_remove = function() {
		$("#popWindow").remove()
	}

	/* 弹出式提示框，默认1.2秒自动消失 */
	const prompt = function(message, style, time) {
		style = (style === undefined) ? 'alert-success' : style;
		time = (time === undefined) ? 1200 : time;
		$('<div>').appendTo('body').addClass('alert ' + style).html(message).show().delay(time).fadeOut();
	}

	/* 成功提醒 */
	this.success_prompt = function(message, time) {
		prompt(message, 'alert-success', time);
	}

	/* 错误提醒 */
	this.danger_prompt = function(message, time) {
		prompt(message, 'alert-danger', time);
	}

	/* 警告提示 */
	this.warning_prompt = function(message, time) {
		prompt(message, 'alert-warning', time);
	}

	/* 消息提示 */
	this.info_prompt = function(message, time) {
		prompt(message, 'alert-info', time);
	}

}

/* 引入script，加载完成后调用回调函数 */
const loadScript = function(src, callback) {
	const script = document.createElement('script');
	const head = document.getElementsByTagName('head')[0];
	script.type = 'text/javascript';
	script.src = src;
	if (script.addEventListener) {
		script.addEventListener('load', function() {
			callback();
		}, false);
	} else if (script.attachEvent) {
		script.attachEvent('onreadystatechange', function() {
			const target = window.event.srcElement;
			if (target.readyState == 'loaded') {
				callback();
			}
		});
	}
	head.appendChild(script);
}
