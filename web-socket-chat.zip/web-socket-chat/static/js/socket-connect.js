/* STOMP客户端、WebSocket连接 */
let stompClient, websocket;
/* 订阅的群集合，可以取消订阅 */
const groupSubscription = [];

/* 开始建立连接 */
const websocket_connect = function(groupCollection) {

	/* 判断浏览器是否支持WebSocket，否则使用SockJS代替，建立WebSocket连接 */
	if ('WebSocket' in window) {
		websocket = new WebSocket('ws://' + tooltip.location_host + '/socketServer/websocket');
	} else {
		websocket = new SockJS('http://' + tooltip.location_host + '/socketServer/sockjs');
	}

	/* 创建STOMP客户端 */
	stompClient = Stomp.over(websocket);

	/* 连接发生错误时将会执行该回调函数 */
	const error_callback = function() {
		console.log('连接stomp服务端发生错误！');
	};

	/* 在客户端连接到STOMP服务器并通过身份验证后回调 */
	const connect_callback = function() {

		console.log('已与stomp服务端成功建立连接！');

		/* 订阅用户消息 */
		stompClient.subscribe('/user/' + $('#own-user-data').data('userId') + '/user/message', function(response) {
			const message = JSON.parse(response.body);
			user_list_message_check_add(message, function() {
				message_label_prompt(message);
			});
		});

		/* 订阅系统消息 */
		stompClient.subscribe('/user/' + $('#own-user-data').data('userId') + '/system/message', function(response) {
			system_message_processing(JSON.parse(response.body));
		});

		/* 订阅群消息 */
		$.each(groupCollection, function(key, value) {
			stomp_client_subscribe_group(value['groupId']);
		});

		/* 心跳检测机制（默认值都是10000ms）*/
		stompClient.heartbeat.outgoing = 20000;
		/* 客户端不从服务端接收心跳包 */
		stompClient.heartbeat.incoming = 0;

	};

	/* 开始连接服务端 */
	stompClient.connect({}, connect_callback, error_callback);

	/* 页面关闭时自动注销 */
	window.close = function() {
		if (stompClient != null) {
			/* 断开连接的回调函数 */
			stompClient.disconnect();
		}
		console.log("stomp client disconnected！");
	}

}

/* 订阅群消息 */
const stomp_client_subscribe_group = function(groupId) {
	/* 订阅群聊天消息 */
	const message = stompClient.subscribe('/user/' + groupId + '/group/message', function(response) {
		const message = JSON.parse(response.body);
		user_list_message_check_add(message, function() {
			message_label_prompt(message);
		});
	});
	/* 订阅系统消息 */
	const recall = stompClient.subscribe('/user/' + groupId + '/system/message', function(response) {
		system_message_processing(JSON.parse(response.body));
	});
	const groupSubscribe = {};
	groupSubscription.push(groupSubscribe[groupId] = {
		'message': message,
		'recall': recall
	});
}

/* 根据groupId取消指定群订阅 */
const query_group_unsubscribe = function(groupId) {
	groupSubscription[groupId]['message'].unsubscribe();
	groupSubscription[groupId]['recall'].unsubscribe();
	delete groupSubscription[groupId];
}

/* 消息输入框 */
const $text_input_box = $('#input-box');
/* 用户资料 */
const $user = $('#own-user-data');

/* 发送消息到 /groupMessage */
const send_message = function(sendType, sendMessage) {
	if (sendMessage) {
		if (window.current_message_object_management['objectType'] == 0) {
			const message = {
				groupId: window.current_message_object_management['objectId'],
				messageType: sendType,
				messageContent: sendMessage
			};
			tooltip.requestLog("/api/group/message", "POST", function() {}, message);
		} else if (window.current_message_object_management['objectType'] == 1) {
			const message = {
				friendId: window.current_message_object_management['objectId'],
				messageType: sendType,
				messageContent: sendMessage
			};
			tooltip.requestLog("/api/user/message", "POST", function() {}, message);
		}
		//stompClient.send("/app/group/message", {}, message);
		$text_input_box.val('');
	} else {
		tooltip.warning_prompt('不能发送空消息!');
	}
}

/* 点击发送文本消息 */
$("#send").bind('click', function() {
	send_message('text', $text_input_box.val().trim());
});

/* 定义快捷键发送消息 */
$('#input-box').bind('keydown', function(event) {
	if ($('#keydown-dropdown').eq(0).find('span').css('opacity') != '0') {
		if (event.which == 13) {
			send_message('text', $text_input_box.val().trim());
			return false;
		}
	} else {
		if (event.ctrlKey && event.which == 13) {
			send_message('text', $text_input_box.val().trim());
		}
	}
});

/* 选择需要发送或上传的文件(多文件上传) */
$('#upload-file-btn').bind('click', function() {
	if ($('#upload-file').length <= 0) {
		$('body').append('<input type="file" id="upload-file" name="file" style="display:none" multiple>');
		$("#upload-file").bind('change', function() {
			const files = $('#upload-file')[0].files;
			const fileData = new FormData();
			for (let i = 0; i < files.length; i++) {
				fileData.append('files', files[i]);
			}
			files_upload(fileData);
		});
	}
	$('#upload-file')[0].click();
});

/* 文件上传并获取返回的文件地址 */
const files_upload = function(fileData) {
	tooltip.uploadFile('/upload', function(response) {
		$.each(response, function(key, value) {
			send_message(value['fileType'], value['filePath']);
		});
	}, fileData);
}

/* 群系统消息整理与处理 */
const system_message_processing = function(response) {
	switch (response['messageType']) {
		case 0:
			let $message_to_replace;
			if (response['requestNick'] == response['responseNick']) {
				$message_to_replace = $('<li>').addClass('center').append($('<div>').addClass('system').append($('<a>')
					.text(response['requestNick'])).append('撤回了一条消息'));
			} else {
				$message_to_replace = $('<li>').addClass('center').append($('<div>').addClass('system').append($('<a>')
					.text(response['requestNick'])).append('撤回了').append($('<a>').text(response['responseNick'])).append('的一条消息'));
			}
			if (response['objectId'] == window.current_message_object_management['objectId']) {
				$('#chat-message-box li[message-id=' + response['messageUuid'] + ']').replaceWith($message_to_replace);
			}
			$('#user-list li[object-id=' + response['objectId'] + ']').find('.user_message').text($message_to_replace.text());
			break;
		case 1:
			console.log('上线提醒');
			break;
		case 2:
			console.log('离线提醒');
			break;
		case 3:
			let $join_group_prompt = $('<li>').addClass('center').append($('<div>').addClass('system').append($('<a>')
				.text(response['responseNick'])).append('加入了群聊！'));
			if (response['objectId'] == window.current_message_object_management['objectId']) {
				$('#chat-message-box').append($join_group_prompt);
			}
			$('#user-list li[object-id=' + response['objectId'] + ']').find('.user_message').text($join_group_prompt.text());
			break;
		case 4:
			let $exit_group_prompt = $('<li>').addClass('center').append($('<div>').addClass('system').append($('<a>').text(
				response['responseNick'])).append('退出了群聊！'));
			if (response['objectId'] == window.current_message_object_management['objectId']) {
				$('#chat-message-box').append($exit_group_prompt);
			}
			$('#user-list li[object-id=' + response['objectId'] + ']').find('.user_message').text($exit_group_prompt.text());
			break;
		case 5:
			let $banned_group_prompt = $('<li>').addClass('center').append($('<div>').addClass('system').append($('<a>').text(
				response['responseNick'])).append('已被管理员禁言！'));
			if (response['objectId'] == window.current_message_object_management['objectId']) {
				$('#chat-message-box').append($banned_group_prompt);
			}
			$('#user-list li[object-id=' + response['objectId'] + ']').find('.user_message').text($banned_group_prompt.text());
			if (response['responseId'] == $('#own-user-data').data('userId')) {
				$('#windows-input').css('pointer-events', 'none');
				$text_input_box.html('禁言中').css('text-align', 'center');
			}
			break;
		case 6:
			let $allowed_speak_prompt = $('<li>').addClass('center').append($('<div>').addClass('system').append($('<a>').text(
				response['responseNick'])).append('已被管理员取消禁言！'));
			if (response['objectId'] == window.current_message_object_management['objectId']) {
				$('#chat-message-box').append($allowed_speak_prompt);
			}
			$('#user-list li[object-id=' + response['objectId'] + ']').find('.user_message').text($allowed_speak_prompt.text());
			if (response['responseId'] == $('#own-user-data').data('userId')) {
				$('#windows-input').css('pointer-events', 'all');
				$text_input_box.html('').css('text-align', 'left');
			}
			break;
	}

	/* 禁言处理工具 */
	const prohibitory_treatment_utils = function(type, userId) {

	}

}
