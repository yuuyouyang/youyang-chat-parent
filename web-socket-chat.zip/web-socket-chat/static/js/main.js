$(function() {

	/* 右侧导航三图标切换,右侧导航栏 */
	$('#windows-body-message-btn').bind('click', function() {
		$('#windows-body-friend,#windows-body-collect').hide();
		if ($('#assistant').hasClass('user_active')) {
			$('#windows-body-assistant').show();
			$('.windows_top_box span').text('消息助手');
		} else {
			$('#windows-body-message,#windows-input').show();
			$('.windows_top_box span').text($('#user-list').find('.user_active .user_name').text());
			if (window.current_message_object_management['objectType'] == 0) {
				$('#group-member-list-btn').show();
			} else {
				$('#group-member-list-btn').hide();
			}
		}
		$(this).css('background', 'url(static/images/icon/head_2_1.png) no-repeat').siblings().css('background', '');
	});
	$('#windows-body-friend-btn').bind('click', function() {
		$('#windows-body-friend').show().siblings().not(':first').hide();
		$('#group-member-list-btn').hide();
		$('.windows_top_box span').text('好友信息');
		$(this).css('background', 'url(static/images/icon/head_3_1.png) no-repeat').siblings().css('background', '');
	});
	$('#windows-body-collect-btn').bind('click', function() {
		$('#windows-body-collect').show().siblings().not(':first').hide();
		$('#group-member-list-btn').hide();
		$('.windows_top_box span').text('我的收藏');
		$(this).css('background', 'url(static/images/icon/head_4_1.png) no-repeat').siblings().css('background', '');
	});
	$('.side_strip_icon a').click(function() {
		$('.side_strip_icon a').eq($(this).index()).addClass('cur').siblings().removeClass('cur');
		$('.middle').hide().eq($(this).index()).show();
	});

	/* 底部扩展键 */
	$('.side_strip_bc').bind('click', function() {
		$('#btn-spread-key').toggle();
	})

	/* 发送快捷键选择实现方式 */
	$('#keydown-dropdown li').bind('click', function() {
		$(this).find('span').css('opacity', '1');
		$(this).siblings().find('span').css('opacity', '0');
	});

	/* 输入框焦点变化时 */
	$('#input-box').bind('focus', function() {
		$('.windows_input,#input-box').css('background', '#fff');
	});
	$('#input-box').bind('blur', function() {
		$('.windows_input,#input-box').css('background', '');
	});

	/* 初始化滚动条插件 */
	$('#user-list,#windows-body-assistant').niceScroll({
		cursorcolor: "#333",
		/* 滚动条的颜色值 */
		cursoropacitymax: 0.2,
		/* 滚动条的透明度值 */
		cursorwidth: 8 /* 滚动条的宽度值 */
	});
	$('#windows-body-friend-btn').one('click', function() {
		setTimeout(function() {
			$('#friends-list').niceScroll({
				cursorcolor: "#333",
				cursoropacitymax: 0.2,
				cursorwidth: 8
			});
		}, 200);
		$('#friends-list .am-accordion-item').bind('click', function() {
			setTimeout(function() {
				$('#friends-list').getNiceScroll().resize();
			}, 200);
		});
	});

	$('#assistant').bind('click', function() {
		if (!$(this).hasClass('user_active')) {
			$('#user-list .user_active').removeClass('user_active');
			$(this).addClass('user_active');
			$('.windows_top_box span').text('消息助手');
			$('#group-member-list-btn,#windows-input,#windows-body-message').hide();
			$('#windows-body-assistant').show();
			window.current_message_object_management = {
				objectId: 'assistant',
				objectType: '-1'
			};
		}
	});

	/* 获取群成员列表 */
	$('#group-member-list-btn').bind('click', function() {
		//$('#group-member-list .am-offcanvas-content').html('<p><a href="javascript:void(0)">成员列表：1/2</a></p>');
		$('#group-member-list .am-offcanvas-content').html('');
		const groupId = window.current_message_object_management['objectId'];
		tooltip.requestLog('/api/group/member/' + groupId, 'GET', function(response) {
			$.each(response, function(key, value) {
				add_online_members_list(value);
			});
		}, {});
	});

	/**
	 * 排序
	 */
	// function online_members_list_sort(){
	// 	var count = $(".am-offcanvas-content").find(".online_members").length;
	// 	$(".state_online").text(count-$(".gray_photos").length+"/"+count);
	// 	$(".am-offcanvas-content").append($(".gray_photos"))
	// }

	/* 将数据添加到群成员列表 */
	const add_online_members_list = function(groupMember) {
		const $groupMember = $('<div>').addClass('group_member').attr('list-id', groupMember['userId']);
		const $userHead = $('<div>').addClass('user_head')
			.append($('<img>').attr('src', tooltip.thumbnailUrl(groupMember['headPortrait'])));
		const $userNick = $('<div>').addClass('friends_text')
			.append($('<div>').addClass('text-overflow').text(groupMember['userNick']));
		$('#group-member-list .am-offcanvas-content').append($groupMember.append($userHead).append($userNick));
	}

});

let acquisition_group_list_init = true;
/* 初始化用户信息 */
const user_data_load = function() {
	tooltip.requestLog('/api/user/information', 'GET', function(response) {
		$('#user-nick').text(response['userNick']);
		$('#user-head').attr('src', tooltip.thumbnailUrl(response['headPortrait']));
		$('#own-head').css({
			'background': 'url(' + tooltip.thumbnailUrl(response['headPortrait']) + ')',
			'background-size': '34px'
		});
		$('#user-phone').text(response['userId']);
		$('#user-address').text(get_address_name(response));
		get_address_name(response['provinceId'], response['cityId'], response['countyId']);
		$('#user-signature').text(response['userSignature']);
		/* 是否是第一次获取消息列表 */
		if (acquisition_group_list_init) {
			gets_the_data_of_the_group();
			gets_the_data_of_the_buddy();
			list_current_message_objects();
			initialize_the_message_helper();
			acquisition_group_list_init = false;
		}
	}, {
		isCoding: true
	});
}

/* 根据省份、城市、县区ID获取地址名称 */
const get_address_name = function(response) {
	let address = '';
	let province = response['provinceId'],
		city = response['cityId'],
		county = response['countyId'];
	address += province != '-1' ? province + ' ' : '';
	address += city != '-1' ? city + ' ' : '';
	address += county != '-1' ? county + ' ' : '';
	return address ? address : '该用户还没填写地址信息';
}

/* 好友验证列表 */
const initialize_the_message_helper = function() {
	tooltip.requestLog('/api/handling', 'GET', function(response) {
		$('#windows-body-assistant').html("");
		if (response) {
			$.each(response, function(key, value) {
				var strVar = "";
				strVar += "<div class=\"am-alert am-alert-secondary\" data-am-alert>";
				strVar += "	<button type=\"button\" class=\"am-close\" title=\"删除验证消息\">×<\/button>";
				if (value['userId'] != $('#own-user-data').data('userId')) {
					strVar += "	<p><b>" + value['userNick'] + "<\/b>对方请求添加你为好友<\/p>";
					strVar += "	<div><label>附加消息：<\/label><span>" + value['additionalMessage'] + "<\/span>";
					strVar += "		<button class=\"add-friend\" title=\"同意并添加为好友\">加为好友<\/button>";
				} else {
					strVar += "	<p><b>" + value['userNick'] + "<\/b>你请求添加对方为好友<\/p>";
					strVar += "	<div><label>附加消息：<\/label><span>" + value['additionalMessage'] + "<\/span>";
					strVar += "		<span style=\"margin-right:10px;float:right;\">等待验证</span>";
				}
				strVar += "	<\/div>";
				strVar += "<\/div>";
				const $message_helper = $(strVar);
				$message_helper.find('.am-close').bind('click', function() {
					alert("删除验证消息 userId=" + value['userId'] + ",friendId=" + value['friendId']);
				});
				$message_helper.find('.add-friend').bind('click', function() {
					value['handlingState'] = 1;
					value['handlingResults'] = 1;
					tooltip.requestLog('/api/handling', 'PUT', function(response) {
						console.log(response)
					}, {
						'userId': value['userId'],
						'friendId': value['friendId'],
						'handlingState': 1,
						'handlingResults': 1
					});
				});
				$('#windows-body-assistant').append($message_helper);
			});
		} else {
			$('#windows-body-assistant').append('<p>暂无好友验证消息!<p>');
		}
	});
}

/* 绑定用户信息 */
const jquery_data_user = function(user) {
	tooltip.requestLog('/api/user/information', 'GET', function(response) {
		$('#own-user-data').data('userId', response['userId'])
			.data('headPortrait', response['headPortrait'])
			.data('userNick', response['userNick'])
			.data('userSex', response['userSex'])
			.data('userSignature', response['userSignature'])
			.data('provinceId', response['provinceId'])
			.data('cityId', response['cityId'])
			.data('countyId', response['countyId']);
	}, {
		isCoding: false
	});
}

/* 获取所有加入群的群资料 */
const gets_the_data_of_the_group = function() {
	tooltip.requestLog('/api/group/data/query/member-id/' + $('#own-user-data').data('userId'),
		'GET',
		function(response) {
			websocket_connect(response);
			append_friends_group_list(response);
		}, {});
}

/* 将数据添加好友列表中的群列表 */
const append_friends_group_list = function(response) {
	if (response.length > 0) {
		const result = data_letter_sort(response, 'groupName');
		for (const key in result) {
			const $group_list = $('<li>').append($('<p>').text(key));
			$.each(result[key], function(key, value) {
				const $box = $('<div>').addClass('friends_box').attr('object-id', value['groupId']);
				const $head = $('<div>').addClass('user_head').append($('<img>')
					.attr('src', tooltip.thumbnailUrl(value['groupPortrait'])));
				const $text = $('<div>').addClass('friends_text').append($('<p>')
					.addClass('user_name').text(value['groupName']));
				$box.append($head).append($text);
				friends_group_list_click($box, value['groupId']);
				$group_list.append($box);
			});
			$('#friends-list .friends-group').append($group_list);
		}
	}
}

/* 为群列表定义点击事件(查看群资料) */
const friends_group_list_click = function($group_list, groupId) {
	$group_list.bind('click', function() {
		$('#user-information').hide();
		$('#group-information').show();
		$('#friends-list .user_active').removeClass('user_active');
		$(this).addClass('user_active');
		tooltip.requestLog('/api/group/data/' + groupId, 'GET', function(response) {
			friends_group_info_fill($('#group-information'), response);
		}, {});
	});
}

/* 查看群资料 */
const friends_group_info_fill = function($group_info, response) {
	const $rlf_group = $("#group-information .rlf-group");
	$rlf_group.eq(0).find('img').attr('src', tooltip.downloadUrl(response['groupPortrait']));
	$rlf_group.eq(1).find('span').text(response['groupAdmin']);
	$rlf_group.eq(2).find('span').text(response['groupName'] + '(' + response['groupId'] + ')');
	$rlf_group.eq(3).find('span')
		.text(response['groupIntroduce'] ? response['groupIntroduce'] : '该群主很懒，还没填写群介绍信息！');
	const $rlf_group_btn = $rlf_group.eq(4).find('button');
	$rlf_group_btn.eq(0).off("click").on("click", function() {
		alert('我的群内昵称');
	});
	$rlf_group_btn.eq(1).off("click").on("click", function() {
		const send_object = {
			objectType: 0,
			objectId: response['groupId']
		};
		user_list_message_check_add(send_object, function() {
			$('#windows-body-message-btn')[0].click();
			$('#user-list li[object-id=' + response['groupId'] + ']')[0].click();
		});
	});
	$rlf_group_btn.eq(2).off("click").on("click", function() {
		alert('退出群聊');
	});
}

/* 获取所有好友的资料 */
const gets_the_data_of_the_buddy = function() {
	tooltip.requestLog('/api/user/friend', 'GET', function(response) {
		append_friends_user_list(response);
	}, {});
}

/* 将数据添加好友列表中的用户列表 */
const append_friends_user_list = function(response) {
	if (response.length > 0) {
		const result = data_letter_sort(response, 'userNick');
		for (const key in result) {
			const $user_list = $('<li>').append($('<p>').text(key));
			$.each(result[key], function(key, value) {
				const $box = $('<div>').addClass('friends_box').attr('object-id', value['userId']);
				const $head = $('<div>').addClass('user_head').append($('<img>')
					.attr('src', tooltip.thumbnailUrl(value['headPortrait'])));
				const $text = $('<div>').addClass('friends_text')
					.append($('<p>').addClass('user_name').text(value['userNick']));
				$box.append($head).append($text)
				friends_user_list_click($box, value['userId']);
				$user_list.append($box);
			});
			$('#friends-list .friends-user').append($user_list);
		}
	}
}

/* 为用户列表定义点击事件(查看好友资料) */
const friends_user_list_click = function($user_list, userId) {
	$user_list.bind('click', function() {
		$('#group-information').hide();
		$('#user-information').show();
		$('#friends-list .user_active').removeClass('user_active');
		$(this).addClass('user_active');
		tooltip.requestLog('/api/user/' + userId, 'GET', function(response) {
			friends_user_info_fill(response);
		}, {});
	});
}
/* 查看好友资料 */
const friends_user_info_fill = function(response) {
	const $rlf_group = $("#user-information .rlf-group");
	$rlf_group.eq(0).find('img').attr('src', tooltip.downloadUrl(response['headPortrait']));
	$rlf_group.eq(1).find('span').text(response['userNick'] + '(' + response['userId'] + ')');
	$rlf_group.eq(2).find('span').text(get_address_name(response));
	$rlf_group.eq(3).find('span').text(response['userSex'] ? '男' : '女');
	$rlf_group.eq(4).find('span')
		.text(response['userSignature'] ? response['userSignature'] : '该用户很懒，还没有填写个性签名！');

	const $rlf_group_btn = $rlf_group.eq(5).find('button');
	$rlf_group_btn.eq(0).off("click").on("click", function() {
		alert('修改好友备注信息');
	});
	$rlf_group_btn.eq(1).off("click").on("click", function() {
		const send_object = {
			userId: $('#own-user-data').data('userId'),
			objectType: 1,
			objectId: response['userId']
		};
		user_list_message_check_add(send_object, function() {
			$('#windows-body-message-btn')[0].click();
			$('#user-list li[object-id=' + response['userId'] + ']')[0].click();
		});
	});
	$rlf_group_btn.eq(2).off("click").on("click", function() {
		alert('删除好友');
	});
}

/* 获取当前消息对象列表 */
const list_current_message_objects = function() {
	tooltip.requestLog('/api/message/objects', 'GET', function(response) {
		$.each(response, function(key, value) {
			append_group_list(value);
		});
	}, {});
}

/* 将数据添加到消息对象列表 */
const append_group_list = function(messageObject) {
	const $group_list = $('<li>').attr('object-id', messageObject['objectId'])
		.attr('object-type', messageObject['objectType']);
	if (messageObject['objectType'] == 0) {
		$group_list.data('groupAdmin', messageObject['groupAdmin']);
	}
	const $group_head = $('<div>').addClass('user_head').append($('<img>')
		.attr('src', tooltip.thumbnailUrl(messageObject['objectHead'])));
	const $group_text = $('<div>').addClass('user_text').append($('<p>').addClass('user_name')
		.text(messageObject['objectName'])).append($('<p>').addClass('user_message').text('[查看消息]'));
	const $group_time = $('<div>').addClass('user_time').text('00-00 00:00');
	group_list_click($group_list.append($group_head).append($group_text).append($group_time));
	$group_list.bind('contextmenu', user_list_contextmenu);
	$('#user-list').append($group_list);
}

/* 当前消息对象 */
window.current_message_object_management = {
	objectId: 'assistant',
	objectType: '-1'
};

/* 为user-list中的每个列定义点击事件  */
const group_list_click = function($group_list) {
	$group_list.bind('click', function() {
		const objectId = $(this).attr('object-id');
		const objectType = $(this).attr('object-type');
		if (window.current_message_object_management['objectId'] != objectId) {
			tooltip.mask_layer_layer();
			switch_to_the_chat_window($(this));
			$(this).find('span').remove();
			window.current_message_object_management = {
				'objectId': objectId,
				'objectType': objectType
			};
			$('#chat-message-box').html($('<li>').addClass('loading'));
			get_group_message_list(objectId, objectType);
		}
		if (objectType == 0) {
			$('#group-member-list-btn').show();
		} else {
			$('#group-member-list-btn').hide();
		}
	});
}

/* 根据群id获取该群最新50条消息 */
const get_group_message_list = function(objectId, objectType) {
	const messageUrl = objectType == 0 ?
		'/api/group/message/lasts/' + objectId :
		'/api/user/message/query/latest/' + objectId;
	tooltip.requestLog(messageUrl, 'GET', function(response) {
		$('.am-pureview-slider').empty();
		if (JSON.stringify(response) != '[]') {
			$.each(response, function(key, value) {
				group_message_processing(value);
			});
			user_list_message_alert(response[response.length - 1], objectId);
		}
		$('#chat-message-box .loading').remove();
		tooltip.mask_layer_remove();
	}, {});
	if (objectType == 0) {
		tooltip.requestLog(
			'/api/group/member/query/' + objectId + '/' + $('#own-user-data').data('userId'),
			'GET',
			function(response) {
				if (response['stateId'] == '2') {
					$('#windows-input').css('pointer-events', 'none');
					$('#input-box').html('禁言中').css('text-align', 'center');
				} else {
					$('#windows-input').css('pointer-events', 'all');
					$('#input-box').html('').css('text-align', 'left');
				}
			}, {});
	} else {
		$('#windows-input').css('pointer-events', 'all');
		$('#input-box').html('').css('text-align', 'left');
	}
}

/* 消息标签提示 */
const message_label_prompt = function(response) {
	let objectId = null;
	if (response['objectType'] == 0 ||
		(response['objectType'] == 1 && response['userId'] == $('#own-user-data').data('userId'))) {
		objectId = response['objectId'];
	} else {
		objectId = response['userId'];
	}
	const $list = $('#user-list li[object-id=' + objectId + ']');
	if (response != null) {
		if (window.current_message_object_management['objectId'] == objectId) {
			group_message_processing(response);
		} else {
			if ($list.find('span').length <= 0) {
				$list.append($('<span>').addClass('am-badge am-badge-warning am-round').text('1'));
			} else {
				const count = parseInt($list.find('span').text());
				if (count < 99) {
					$list.find('span').text(count + 1);
				}
			}
		}
		user_list_message_alert(response, objectId);
	}
}

/* 判断当前id是否在消息对象列表，不在则添加 */
const user_list_message_check_add = function(response, callback) {
	let $list = null;
	const messageObject = {
		objectType: response['objectType']
	};
	if (response['objectType'] == 0 ||
		(response['objectType'] == 1 && response['userId'] == $('#own-user-data').data('userId'))) {
		$list = $('#user-list li[object-id=' + response['objectId'] + ']');
		messageObject['objectId'] = response['objectId'];
	} else {
		$list = $('#user-list li[object-id=' + response['userId'] + ']');
		messageObject['objectId'] = response['userId'];
	}
	if ($list.length <= 0) {
		tooltip.requestLog('/api/message/objects', 'POST', function(data) {
			tooltip.requestLog('/api/message/objects/query', 'GET', function(data2) {
				append_group_list(data2);
				callback();
			}, messageObject);
		}, messageObject);
	} else {
		callback();
	}
}

/* 判断消息类型，在消息对象列表预览消息 */
const user_list_message_alert = function(response, objectId) {
	const $list = $('#user-list li[object-id=' + objectId + ']');
	if (response['messageType'].indexOf('text') != -1) {
		$list.find('.user_message').text(response['messageContent']);
	}
	if (response['messageType'].indexOf('image') != -1) {
		$list.find('.user_message').text('[图片]');
	}
	$list.find('.user_time').text(response['timeString']);
}

/* 将消息添加到消息窗口 */
const group_message_processing = function(response) {
	let $message;
	if ($('#own-user-data').data('userId') == response['userId']) {
		$message = $('<li>').addClass('me').append(message_create(response))
			.attr('message-id', response['messageUuid'])
	} else {
		$message = $('<li>').addClass('other').append(message_create(response))
			.attr('message-id', response['messageUuid'])
		$message.append($('<div>').addClass('other_nick').text('【' + response['userNick'] + '】'));
	}
	$message.data('message-type', response['messageType'])
		.data('userId', response['userId'])
		.data('userNick', response['userNick']);
	const $message_box = $('#chat-message-box');
	$message.append(message_type(response)).find('img').on('load', function() {
		$message_box.append($('<li>').delay(10).remove());
		$message_box.scrollTop($message_box[0].scrollHeight);
	});
	$message_box.append($message).scrollTop($message_box[0].scrollHeight);
}

/* 创建一个消息框 */
const message_create = function(response) {
	return $('<div>')
		.bind('click', function() {
			view_user_profile(response['userId']);
		})
		.addClass('head_img')
		.css({
			'background': 'url(' + tooltip.thumbnailUrl(response['headPortrait']) + ')',
			'background-size': '100%'
		})
		.hover(function() {
			$(this).css("cursor", "pointer");
		}, function() {
			$(this).css("cursor", "default");
		})
		.attr('title', response['userNick']);
}

/* 根据消息类型渲染消息气泡 */
const message_type = function(response) {
	if (response['messageType'].indexOf('text') != -1) {
		return $('<span><pre>' + response['messageContent'] + '</pre></span>').bind('contextmenu', chat_bubble_contextmenu);
	}
	if (response['messageType'].indexOf('image') != -1) {
		const $message_img = $('<img>').attr('src', tooltip.thumbnailUrl(response['messageContent']))
			.attr('alt', response['messageContent'])
			.attr('data-rel', tooltip.urlPrefix('/download?filename=' + response['messageContent']));
		const $message_div = $('<div>').addClass('am-gallery-overlay')
			.append($message_img).append($('<div>').addClass('am-gallery-title').html(response['messageContent']))
			.attr('title', response['messageContent'])
			.on('contextmenu', chat_bubble_contextmenu);
		return $message_div.addClass($('#own-user-data').data('userId') == response['userId'] ? 'me_img' : 'other_img');
	}
}

let message_list_not_displayed = true;
/* 初始化消息窗口滚动条,滚动条置底 */
const windows_body_message_scroll_bottom = function() {
	if (message_list_not_displayed) {
		$('#chat-message-box').niceScroll({
			cursorcolor: "#333",
			cursoropacitymax: 0.2,
			cursorwidth: 8
		});
		message_list_not_displayed = false;
	}
}

/* 完成其他窗口到聊天窗口切换 */
const switch_to_the_chat_window = function($this) {
	if (!$this.hasClass('user_active')) {
		$('#group-member-list-btn,#windows-input,#windows-body-message').show();
		$('#windows-body-assistant').hide();
		windows_body_message_scroll_bottom();
		$('#user-list .user_active').removeClass('user_active');
		$this.addClass('user_active');
		$('.windows_top_box span').text($this.find('.user_name').text());
	}
}

/* 聊天气泡右键菜单事件 */
const chat_bubble_contextmenu = function(e) {
	const messageId = $(e.target).parents("li").attr('message-id');
	const messageType = $(e.target).parents("li").data('message-type');
	const userId = $(e.target).parents("li").data('userId');
	const objectId = window.current_message_object_management['objectId'];
	const objectType = window.current_message_object_management['objectType'];

	const clicked = function() {
		alert('Item clicked!')
	}
	/* 复制 */
	const copy_text = function() {
		$("#copy-element").val($(e.target).parents("span").text());
		document.getElementById("copy-element").select();
		document.execCommand("copy");
		tooltip.info_prompt("消息已复制到剪切板!");
	}
	/* 撤回消息 */
	const recallMessage = function() {
		if (objectType == 0) {
			tooltip.request('/api/group/message/' + messageId, 'DELETE', function(response) {
				if (!response['state']) {
					console.log(response['message']);
				}
			}, {});
		} else if (objectType == 1) {
			tooltip.request('/api/user/message/' + messageId, 'DELETE', function(response) {
				if (!response['state']) {
					console.log(response['message']);
				}
			}, {});
		}
	}
	/* 下载（另存为）*/
	const save_as = function() {
		$('<a>').attr('target', '_blank').attr('href', $(e.target).attr("data-rel"))[0].click();
	}
	/* 查看用户资料 */
	const view_information = function() {
		view_user_profile(userId);
	}
	/* 禁言状态管理 */
	const banned_management = function(stateId) {
		tooltip.requestLog('/api/group/member/state/' + objectId + '/' + userId, 'PUT', function(response) {}, {
			'groupId': objectId,
			'memberId': userId,
			'stateId': stateId
		});
	}
	const items = [];
	if (messageType.indexOf('text') != -1) {
		items.push({
			title: '复制',
			fn: copy_text
		});
	}
	if (messageType.indexOf('image') != -1) {
		items.push({
			title: '图片另存为',
			fn: save_as
		});
	}
	if (objectType == 0) {
		const groupAdmin = $('#user-list .user_active').data('groupAdmin');
		if (userId == $('#own-user-data').data('userId') || groupAdmin == $('#own-user-data').data('userId')) {
			items.push({
				title: '撤回消息',
				fn: recallMessage
			});
		}
	} else {
		if (userId == $('#own-user-data').data('userId')) {
			items.push({
				title: '撤回消息',
				fn: recallMessage
			});
		}
	}
	if (userId != $('#own-user-data').data('userId')) {
		if (items.length > 0) {
			items.push({});
		}
		items.push({
			title: '查看资料',
			fn: view_information
		});
		if (objectType == 0) {
			const groupAdmin = $('#user-list .user_active').data('groupAdmin');
			if ($('#friends-list .friends-user .friends_box[object-id=' + userId + ']').length > 0) {
				items.push({
					title: '单独回复',
					fn: clicked
				});
			} else {
				items.push({
					title: '添加好友',
					fn: clicked
				});
			}
			if (groupAdmin == $('#own-user-data').data('userId')) {
				items.push({});
				$.ajax({
					url: tooltip.urlPrefix('/api/group/member/query/' + objectId + '/' + userId),
					type: 'GET',
					async: false,
					headers: {
						Authorization: localStorage.getItem("key_token")
					},
					success: function(response) {
						const groupMember = response['data'];
						if (groupMember['stateId'] == '1') {
							items.push({
								title: '一键禁言',
								fn: function() {
									banned_management('2');
								}
							});
						} else {
							items.push({
								title: '取消禁言',
								fn: function() {
									banned_management('1');
								}
							});
						}
					}
				});
			}
		}
	}
	items.push({});
	items.push({
		title: '清屏',
		fn: function() {
			$('#chat-message-box').html('');
		}
	});
	basicContext.show(items, e.originalEvent)
}

/* 查看用户资料 */
const view_user_profile = function(userId) {
	tooltip.requestLog('/api/user/' + userId, 'GET', function(response) {
		$group_information = $($('#user-information')[0].cloneNode(true));
		const $rlf_group = $group_information.find('.rlf-group');
		$rlf_group.eq(0).find('img').attr('src', tooltip.downloadUrl(response['headPortrait']));
		$rlf_group.eq(1).find('span').text(response['userNick'] + '(' + response['userId'] + ')');
		$rlf_group.eq(2).find('span').text(get_address_name(response));
		$rlf_group.eq(3).find('span').text(response['userSex'] ? '男' : '女');
		$rlf_group.eq(4).find('span')
			.text(response['userSignature'] ? response['userSignature'] : '该用户很懒，还没有填写个性签名！');
		$group_information.find('.wlfg-wrap').eq(5).remove();
		$('#friend-information-modal .am-modal-bd').html($group_information.show());
		$('#friend-information-modal').modal('open');
	}, {});
}

/* 聊天对象列表右键菜单事件 */
const user_list_contextmenu = function(e) {
	const objectId = $(e.target).parents("li").attr('object-id') || $(e.target).attr('object-id');
	const objectType = $(e.target).parents("li").attr('object-type') || $(e.target).attr('object-type');
	const clicked = function() {
		alert('{object-id:' + objectId + ',object-type:' + objectType + '}');
	}
	/* 发送即使消息 */
	const send_message = function() {
		if ($(e.target).attr('object-type')) {
			$(e.target)[0].click();
		} else {
			$(e.target).parents("li")[0].click();
		}
		$('#input-box').focus();
	}
	/* 查看资料 */
	const view_information = function() {
		if (objectType == 0) {
			tooltip.requestLog('/api/group/data/' + objectId, 'GET', function(response) {
				$group_information = $($('#group-information')[0].cloneNode(true));
				const $rlf_group = $group_information.find('.rlf-group');
				$rlf_group.eq(0).find('img').attr('src', tooltip.downloadUrl(response['groupPortrait']));
				$rlf_group.eq(1).find('span').text(response['groupAdmin']);
				$rlf_group.eq(2).find('span').text(response['groupName'] + '(' + response['groupId'] + ')');
				$rlf_group.eq(3).find('span')
					.text(response['groupIntroduce'] ? response['groupIntroduce'] : '该群主很懒，还没填写群介绍信息！');
				$group_information.find('.wlfg-wrap').eq(4).remove();
				$('#friend-information-modal .am-modal-bd').html($group_information.show());
				$('#friend-information-modal').modal('open');
			}, {});
		} else {
			view_user_profile(objectId);
		}
	}
	/* 查看历史消息 */
	const view_history_messages = function() {
		$('#message-history-modal').modal('open');
		$('#message-history-modal').data('objectType', objectType).data('objectId', objectId);
		getPageQueryMessage();
	}
	/* 从会话列表移除 */
	const remove_from_list = function() {
		tooltip.requestLog('/api/message/objects/' + objectId, 'DELETE', function(response) {
			$(e.target).parents("li").remove();
			$('#assistant')[0].click();
		}, {});
	}

	let items;
	if (objectType == 0) {
		items = [{
			title: '发送群消息',
			fn: send_message
		}, {}, {
			title: '查看群资料',
			fn: view_information
		}, {
			title: '查看消息记录',
			fn: view_history_messages
		}, {}, {
			title: '屏蔽该群消息',
			fn: clicked
		}, {
			title: '修改我的群内昵称',
			fn: clicked
		}, {}, {
			title: '从会话列表移除',
			fn: remove_from_list
		}];
		const groupAdmin = $(e.target).parents("li").data('groupAdmin') || $(e.target).data('groupAdmin');
		if (groupAdmin == $('#own-user-data').data('userId')) {
			items.push({
				title: '解散该群',
				fn: clicked
			});
		} else {
			items.push({
				title: '退出该群',
				fn: clicked
			});
		}
	} else {
		items = [{
			title: '发送即使消息',
			fn: send_message
		}, {}, {
			title: '查看资料',
			fn: view_information
		}, {
			title: '消息记录',
			fn: view_history_messages
		}, {}, {
			title: '屏蔽此人消息',
			fn: clicked
		}, {
			title: '修改好友备注',
			fn: clicked
		}, {}, {
			title: '从会话列表移除',
			fn: remove_from_list
		}, {
			title: '删除好友',
			fn: clicked
		}];
	}
	basicContext.show(items, e.originalEvent)
}

/* 初始化用户信息，并与服务端建立websocket连接 */
window.onload = function() {
	loadScript('static/js/chinese-dictionary.js', function() {
		user_data_load();
		jquery_data_user();
	});
}
