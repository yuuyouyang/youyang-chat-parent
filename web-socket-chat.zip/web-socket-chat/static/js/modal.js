$(function() {

	/* 注销模态框，询问是否注销登录 */
	$('#chat-close-btn').bind('click', function() {
		$('#chat-close-confirm').modal({
			relatedElement: this,
			onConfirm: function() {
				tooltip.request('/user/logout', 'GET', function(response) {
					tooltip.info_prompt('已注销登录', 800);
					window.location.reload();
				}, {});
			},
			onCancel: function() {
				tooltip.info_prompt('注销登录已取消', 800);
			}
		});
	});

	/* 个人资料修改界面 */
	const personal_data_modal_init = function() {
		/* 弹出图片裁剪框 */
		$('#personal-data-modal .avator-btn-fake').bind('click', function() {
			picture_clipping_tool($head);
		});
		/*
		 * 根据id获取下级地址信息
		 * @param codeId 根据此id获取其下级地址集合
		 * @param $object 将获取的地址集合填充到该标签
		 * @param checkedId 数据填充完成后根据value默认选中
		 */
		const query_address_set = function(codeId, $object, checkedId) {
			tooltip.requestLog('/address/' + codeId, 'GET', function(response) {
				$.each(response, function(key, value) {
					$object.append('<option value="' + value['codeId'] + '">' + value['addressName'] + '</option>');
				});
				$object.val(checkedId != null ? checkedId : '-1');
			}, {});
		}
		const $user = $('#own-user-data');
		const $head = $('#personal-head');
		const $nick = $('#personal-nick');
		const $province = $('#province-select');
		const $city = $('#city-select');
		const $county = $('#county-select');
		const $signature = $('#about-me');
		const $sex = $(':radio[name="sex"]');
		/* 省份改变时更新其下列表 */
		$province.bind('change', function() {
			$city.html('<option value="-1">选择城市</option>');
			$county.html('<option value="-1">选择区县</option>');
			query_address_set($(this).val(), $("#city-select"), '-1');
		});
		/* 县级联动 */
		$city.bind('change', function() {
			$county.html('<option value="-1">选择区县</option>');
			query_address_set($(this).val(), $county, '-1');
		});
		personal_data_init();

		/* 个人资料初始化 */
		function personal_data_init() {
			/* 获取头像 */
			$head.attr('src', tooltip.downloadUrl($user.data('headPortrait')));
			/* 获取昵称 */
			$nick.val($user.data('userNick'));
			/* 选中相对应性别 */
			$sex.eq($user.data('userSex') ? 0 : 1).attr("checked", true);
			/* 初始化各级地址并选中 */
			query_address_set('000000', $province, $user.data('provinceId'));
			if ($user.data('provinceId')) {
				query_address_set($user.data('provinceId'), $city, $user.data('cityId'));
				query_address_set($user.data('cityId'), $county, $user.data('countyId'));
			}
			/* 获取个性签名 */
			$signature.val($user.data('userSignature'));
			$("#about-me-count").text(128 - $signature.val().length);
			/* 个人资料字数提示 */
			$signature.bind('keydown', function() {
				$('#about-me-count').text(128 - $(this).val().length);
			});
		}

		/* 个人资料保存点击事件 */
		$('#profile-submit').bind('click', function() {
			/* 昵称非空校验 */
			if ($nick.val()) {
				personal_modified_value_match();
			} else {
				tooltip.danger_prompt('昵称不能为为空！');
			}
		});
		let personal_modified_value_count = 0;
		/* 判断数据变化(获取修改后的数据) */
		const personal_modified_value_match = function() {
			const personal_form_data = new FormData();
			if ($head.attr('src') != tooltip.downloadUrl($user.data('headPortrait'))) {
				personal_form_data.append('file', convert_base64_url_to_blob($head.attr('src')), 'user.png');
				personal_form_data.append('headPortrait', $user.data('headPortrait'));
				personal_modified_value_count++;
			}
			if ($nick.val() != $user.data('userNick')) {
				personal_form_data.append('userNick', $nick.val());
				personal_modified_value_count++;
			}
			if ($user.data('provinceId') != $province.val()) {
				personal_form_data.append('provinceId', $province.val());
				personal_modified_value_count++;
			}
			if ($user.data('cityId') != $city.val()) {
				personal_form_data.append('cityId', $city.val());
				personal_modified_value_count++;
			}
			if ($user.data('countyId') != $county.val()) {
				personal_form_data.append('countyId', $county.val());
				personal_modified_value_count++;
			}
			if ($user.data('userSex') != $sex.eq(0).prop('checked')) {
				personal_form_data.append('userSex', $sex.eq(0).prop('checked'));
				personal_modified_value_count++;
			}
			if ($user.data('userSignature') != $signature.val()) {
				personal_form_data.append('userSignature', $signature.val());
				personal_modified_value_count++;
			}
			/* 判断参数个数，userId为默认参数，无需修改 */
			if (personal_modified_value_count > 0) {
				personal_form_data.append('userId', $user.data('userId'));
				personal_data_submit(personal_form_data);
			} else {
				tooltip.warning_prompt('请先进行有效修改！');
			}
		}
		/* 个人资料提交，保存资料 */
		const personal_data_submit = function(personal_form_data) {
			tooltip.uploadFile('/api/user/' + $user.data('userId'), function(response) {
				if (response['state']) {
					tooltip.success_prompt(response['data']);
					$('#personal-data-modal').modal('close');
					user_data_load();
				} else {
					tooltip.danger_prompt(response['message']);
				}
			}, personal_form_data);
		}
	}
	/* 个人资料初始化 */
	$('#personal-data-btn').one('click', function() {
		personal_data_modal_init();
	});


	/* 好友助手 */
	const friends_assistant_modal_init = function() {
		/* 启用滚动条 */
		$('#query-user,#query-group').niceScroll('.search_message', {
			cursorcolor: "#000",
			cursoropacitymax: 0.9,
			cursorwidth: 4
		});
		/* 禁用触控 */
		$('#friends_assistant_modal .am-tabs').tabs({
			noSwipe: 1
		});

		/* 查询用户、添加好友 */
		function query_users_to_add_friends() {
			function search_user_result() {
				const keyboard = $('#query-user-keyboard').val();
				tooltip.requestLog('/api/user/query/search/' + keyboard, 'GET', function(response) {
					traverse_user_list(response);
				}, {});
			}
			/* 为指定元素定义点击事件，提交好友申请 */
			function add_friend_click($btn, user_id) {
				/** 提交事务 */
				function handling_sumbit() {
					$('#friend-verification-prompt').modal({
						relatedTarget: this,
						onConfirm: function(e) {
							tooltip.request('/api/handling', "POST", function(response) {
								if (response['state']) {
									tooltip.success_prompt(response['data']);
								} else {
									tooltip.warning_prompt(response['message']);
								}
							}, {
								'friendId': user_id,
								'additionalMessage': e.data || ''
							});
						},
						onCancel: function(e) {
							tooltip.success_prompt("操作已取消!");
						}
					});
				}
				$btn.bind('click', function() {
					if (user_id == $('#own-user-data').data('userId')) {
						tooltip.warning_prompt('不能添加自己为好友！');
						return;
					}
					tooltip.request('/api/user/friend/' + user_id, "GET", function(response) {
						if (response['data']) {
							tooltip.warning_prompt('检测到你与对方已是好友，无需重复添加！');
						} else {
							tooltip.request('/api/handling/' + user_id, "GET", function(response) {
								if (response['data']) {
									tooltip.warning_prompt('你已发起过好友请求，请静待处理！');
								} else {
									handling_sumbit();
								}
							}, {});
						}
					}, {});
				});
			}
			/* 将查询到的用户信息填充到找人界面，用于添加好友 */
			function traverse_user_list(response) {
				$('#query-user ul').empty();
				$.each(response, function(key, value) {
					const $user_li = $('<li></li>');
					const $user_div = $('<div></div>').addClass('am-gallery-item');
					const $user_head = $('<img>').attr('src', tooltip.urlPrefix('/download?filename=' + value['headPortrait']));
					const $user_name = $('<h3></h3>').addClass('am-gallery-title')
						.attr('title', value['userNick'] + '(' + value['userId'] + ')')
						.text(value['userNick'] + '(' + value['userId'] + ')');
					const $user_hint = $('<div></div>').addClass('am-gallery-desc').html('可能认识').append($('<a></a>').text('添加好友+'));
					add_friend_click($user_hint.find('a'), value['userId']);
					$user_li.append($user_div.append($user_head).append($user_name).append($user_hint));
					$('#query-user ul').append($user_li);
				});
				$('#query-user').getNiceScroll().resize();
			}

			$('#query-user-keyboard').bind('keydown', function(event) {
				if (event.which == 13) {
					search_user_result();
				}
			});
			$('#query-user .input_ico').bind('click', function() {
				search_user_result();
			});

			tooltip.requestLog('/api/user/query/random', 'GET', function(response) {
				traverse_user_list(response);
			}, {});
		}

		/* 查找群、加入群 */
		function query_join_group_chat() {
			function search_group_result() {
				const keyboard = $('#query-group-keyboard').val();
				tooltip.requestLog('/api/group/data/query/search/' + keyboard, 'GET', function(response) {
					traverse_group_list(response);
				}, {});
			}

			/* 为指定元素定义点击事件，提交入群申请 */
			function join_group_click($btn, group_Id) {
				const member = {
					groupId: group_Id,
					memberId: $('#own-user-data').data('userId'),
					memberNick: $('#own-user-data').data('userNick'),
					stateId: 1
				};
				$btn.bind('click', function() {
					tooltip.request('/api/group/member', "POST", function(response) {
						if (response['state']) {
							tooltip.success_prompt(response['data']);
							user_list_message_check_add(group_Id, 0, function() {
								stomp_client_subscribe_group(group_Id);
							});
						} else {
							tooltip.warning_prompt(response['message']);
						}
					}, member);
				})
			}

			/* 将查询到的数据填充到找群界面，用于加入群聊 */
			function traverse_group_list(response) {
				$('#query-group ul').empty();
				$.each(response, function(key, value) {
					const $group_li = $('<li></li>');
					const $group_div = $('<div></div>').addClass('am-gallery-item');
					const $group_head = $('<img>').attr('src', tooltip.urlPrefix('/download?filename=' + value['groupPortrait']));
					const $group_name = $('<h3></h3>').addClass('am-gallery-title')
						.attr('title', value['groupName'] + '(' + value['groupId'] + ')')
						.text(value['groupName'] + '(' + value['groupId'] + ')');
					const $group_hint = $('<div></div>').addClass('am-gallery-desc').html('共24人')
						.append($('<a></a>').text('加入群聊+'));
					join_group_click($group_hint.find('a'), value['groupId']);
					$group_li.append($group_div.append($group_head).append($group_name).append($group_hint));
					$('#query-group ul').append($group_li);
				});
				$('#query-group').getNiceScroll().resize();
			}

			$('#query-group-keyboard').bind('keydown', function(event) {
				if (event.which == 13) {
					search_group_result();
				}
			});
			$('#query-group .input_ico').bind('click', function() {
				search_group_result();
			});
			tooltip.requestLog('/api/group/data/query/random', 'GET', function(response) {
				traverse_group_list(response);
			}, {});
		}

		/* 创建群或管理群（每个账号有且只能创建且管理一个群） */
		function create_update_group_chat() {
			const $group_head = $('#group-head').data('groupPortrait', '#head#');
			const $group_id = $('#create-group-id').data('groupId', '#id#');
			const $group_name = $('#group-name').data('groupName', '#name#');
			const $group_introduce = $('#group-introduce').data('groupIntroduce', '#introduce#');

			/* 群管理界面数据刷新 */
			function create_group_load() {
				tooltip.requestLog('/api/group/data/query/user-id/' + $('#own-user-data').data('userId'), 'GET', function(
					response) {
					if (response) {
						$('#create-group-btn').text('管理群');
						$group_head.data('groupPortrait', response['groupPortrait'])
							.attr('src', tooltip.urlPrefix('/download?filename=' + response['groupPortrait']));
						$group_id.data('groupId', response['groupId']).val(response['groupId']);
						$group_name.data('groupName', response['groupName']).val(response['groupName']);
						$group_introduce.data('groupIntroduce', response['groupIntroduce']).text(response['groupIntroduce']);
						// 修改群资料
						group_data_click_submit('/api/group/data/' + response['groupId']);
					} else {
						$('#create-group-btn').text('新建群');
						// 新建群聊
						group_data_click_submit('/api/group/data');
					}
				}, {});
			}

			create_group_load();
			/* 群资料提交点击事件 */
			const group_data_click_submit = function(submitUrl) {
				$('#create-group-submit').unbind('click').bind('click', function() {
					if ($group_head.attr('src') == 'static/images/upload.png') {
						tooltip.danger_prompt('群头像不能为空！');
					} else if (!$group_name.val()) {
						tooltip.danger_prompt('群名称不能为空！');
					} else {
						group_form_data_submit(submitUrl);
					}
				});
			}
			let group_form_data_count = 0;
			/* 群管理界面初始化 */
			const group_form_data_submit = function(submitUrl) {
				let groupData = new FormData();
				groupData.append('groupAdmin', $('#own-user-data').data('userId'));
				groupData.append('groupId', $group_id.data('groupId'));
				if ($group_name.val() != $group_name.data('groupName')) {
					groupData.append('groupName', $group_name.val());
					group_form_data_count++;
				}
				if ($group_head.attr('src') != tooltip.downloadUrl($group_head.data('groupPortrait'))) {
					groupData.append('groupPortrait', $group_head.data('groupPortrait'));
					groupData.append('file', convert_base64_url_to_blob($group_head.attr('src')), 'group.png');
					group_form_data_count++;
				}
				if ($group_introduce.val() != $group_introduce.data('groupIntroduce')) {
					groupData.append('groupIntroduce', $group_introduce.val());
					group_form_data_count++;
				}
				if (group_form_data_count > 0) {
					group_data_submit(submitUrl, groupData);
				} else {
					tooltip.warning_prompt('请做出有效修改后在提交！');
				}
			}
			/* 弹出图片裁剪框 */
			$('#create-group .avator-btn-fake').bind('click', function() {
				picture_clipping_tool($group_head);
			});
			/* 群介绍字数提示 */
			$group_introduce.bind('keydown', function() {
				$('#group-introduce-count').text(128 - $(this).val().length);
			});
			/* 群资料提交，修改群资料或创建新群 */
			const group_data_submit = function(submitUrl, groupData) {
				tooltip.uploadFile(submitUrl, function(response) {
					if (response['state']) {
						create_group_load();
						group_form_data_count = 0;
						tooltip.success_prompt(response['data']);
					} else {
						console.log(response['message']);
						tooltip.danger_prompt(response['message']);
					}
				}, groupData);
			}
		}

		query_users_to_add_friends();
		query_join_group_chat();
		create_update_group_chat();
	}

	/* 好友助手初始化 */
	$('#friends_assistant_modal-btn').one('click', function() {
		friends_assistant_modal_init();
	});

	/* 查看历史消息 */
	$('#message-history-btn').bind('click', function() {
		const objectType = window.current_message_object_management['objectType'];
		const objectId = window.current_message_object_management['objectId'];
		$('#message-history-modal').data('objectType', objectType).data('objectId', objectId);
		getPageQueryMessage();
	});
	$('#message-history-btn').one('click', function() {
		setTimeout(function() {
			$('#message-history-modal .comments-message-list').niceScroll('.am-comments-list', {
				cursorcolor: "#333",
				cursoropacitymax: 0.2,
				cursorwidth: 8
			});
		}, 500)
		$('#message-history-modal .am-pagination li').bind('click', function() {
			getPageQueryMessage($(this).attr('pageNum'));
		});
	});

});

/* 初始化历史消息模态框, 获取指定页数据 */
const getPageQueryMessage = function(currentNum) {
	const objectType = $('#message-history-modal').data('objectType');
	const objectId = $('#message-history-modal').data('objectId');;
	if (objectType == 0) {
		tooltip.requestLog('/api/group/message/page', 'GET', function(response) {
			render_message_list(response);
			$('#message-history-modal .comments-message-list').getNiceScroll().resize();
			setTimeout(function() {
				$('#message-history-modal .comments-message-list').getNiceScroll().resize();
			}, 500)
		}, {
			groupId: objectId,
			pageNum: currentNum
		});
	} else {
		tooltip.requestLog('/api/user/message/page', 'GET', function(response) {
			render_message_list(response);
			$('#message-history-modal .comments-message-list').getNiceScroll().resize();
			setTimeout(function() {
				$('#message-history-modal .comments-message-list').getNiceScroll().resize();
			}, 500)
		}, {
			friendId: objectId,
			pageNum: currentNum
		});
	}
}

/* 渲染消息列表 */
const render_message_list = function(response) {
	const $message_list = $('#message-history-modal .am-comments-list').empty();
	$.each(response['list'], function(key, value) {
		const $headImg = $('<a>').append($('<img>').addClass('am-comment-avatar')
			.attr('src', tooltip.thumbnailUrl(value['headPortrait'])));
		const $meta = $('<div>').addClass('am-comment-meta').append($('<a>')
			.addClass('am-comment-author').text(value['userNick'])).append($('<time>').text(value['messageTime']));
		const $header = $('<div>').addClass('am-comment-hd').append($meta);
		const $content = $('<div>').addClass('am-comment-bd').html(history_message_type(value));
		const $main = $('<div>').addClass('am-comment-main').append($header).append($content);
		const $list = $('<li>').append($headImg).append($main);
		$message_list.append($list);
	});
	render_paging_component(response);
}

/* 根据消息类型渲染消息气泡 */
const history_message_type = function(response) {
	if (response['messageType'].indexOf('text') != -1) {
		return response['messageContent'];
	}
	if (response['messageType'].indexOf('image') != -1) {
		return $('<img>').attr('src', tooltip.thumbnailUrl(response['messageContent']))
			.attr('title', response['messageContent'])
	}
}

/* 渲染分页组件 */
const render_paging_component = function(response) {
	const $pagination = $('#message-history-modal .am-pagination');
	$pagination.find('.am-pagination-first').attr('pageNum', response['navigateFirstPage']);
	$pagination.find('.am-pagination-prev')
		.attr('pageNum', response['prePage'] != '0' ? response['prePage'] : response['navigateLastPage']);
	const $next = $pagination.find('.am-pagination-next')
		.attr('pageNum', response['nextPage'] != '0' ? response['nextPage'] : response['navigateFirstPage']);
	$pagination.find('.am-pagination-last').attr('pageNum', response['navigateLastPage']);
	$pagination.find('.nums').remove();
	$.each(response['navigatepageNums'], function(key, value) {
		if (value != response['pageNum']) {
			$next.before($('<li>').addClass('nums').append($('<a>').text(value)).bind('click', function() {
				getPageQueryMessage(response['pageNum']);
			}));
		} else {
			$next.before($('<li>').addClass('nums').addClass('am-active').append($('<a>').text(value))
				.bind('click', function() {
					getPageQueryMessage(response['pageNum']);
				}));
		}
	});
}
